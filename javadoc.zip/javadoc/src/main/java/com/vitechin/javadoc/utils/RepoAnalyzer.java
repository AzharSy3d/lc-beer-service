package com.vitechin.javadoc.utils;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Pattern;

@Component
public class RepoAnalyzer {
    private static final Pattern GITHUB_URL_PATTERN =
        Pattern.compile("^(https?://github.com/.*?)(\\.git)?$");
        
    public Path resolvePath(String input) throws IOException {
        if (GITHUB_URL_PATTERN.matcher(input).matches()) {
            System.out.println("GitHub Repository: " + input);
            return cloneRepository(input);
        }
        Path path = Paths.get(input);
        if (!Files.exists(path)) {
            throw new IOException("Path does not exist: " + input);
        }
        return path;
    }
    private Path cloneRepository(String repoUrl) throws IOException {
        // Extract the repository name from the URL
        String repoName = repoUrl.substring(repoUrl.lastIndexOf('/') + 1).replace(".git", "");
        String userHome = System.getProperty("user.home");
        Path tempDir = Paths.get(userHome, "repo", "AiJavaDocs", repoName);

        // Create the directory if it doesn't exist
        if (!Files.exists(tempDir)) {
            Files.createDirectories(tempDir);
        }

        System.out.println("Cloning repository to: " + tempDir);

        // Use ProcessBuilder to execute the git clone command
        ProcessBuilder processBuilder = new ProcessBuilder("git", "clone", repoUrl, tempDir.toString());
        processBuilder.inheritIO(); // To inherit the IO of the current process

        try {
            Process process = processBuilder.start();
            int exitCode = process.waitFor();
            if (exitCode != 0) {
                throw new IOException("Failed to clone repository, exit code: " + exitCode);
            }
            return tempDir;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Failed to clone repository", e);
        }
    }
    private Path cloneRepository1(String repoUrl) throws IOException {
        Path tempDir = Files.createTempDirectory("javadoc-generator");
        System.out.println("Cloning repository to: " + tempDir);
        
        try (Git git = Git.cloneRepository()
                .setURI(repoUrl)
                .setDirectory(tempDir.toFile())
                .call()) {
            return tempDir;
        } catch (GitAPIException e) {
            throw new IOException("Failed to clone repository", e);
        }
    }
}
