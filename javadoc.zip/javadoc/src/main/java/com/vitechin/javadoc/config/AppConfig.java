package com.vitechin.javadoc.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.bedrockruntime.BedrockRuntimeClient;

@Configuration
@EnableAsync
@EnableConfigurationProperties(FilterConfig.class)
public class AppConfig {

    @Bean
    public TaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(100);
        executor.setMaxPoolSize(100);
        executor.setQueueCapacity(500);
        executor.setThreadNamePrefix("DocGen-");
        executor.initialize();
        return executor;
    }

    @Bean
    public BedrockRuntimeClient bedrockClient() {
        return BedrockRuntimeClient.builder()
            .region(Region.of("us-west-1"))
            .build();
    }

//    @PreDestroy
//    public void cleanup() {
//        fileExecutor.shutdown();
//        methodExecutor.shutdown();
//        try {
//            if (!fileExecutor.awaitTermination(60, TimeUnit.SECONDS)) {
//                fileExecutor.shutdownNow();
//            }
//            if (!methodExecutor.awaitTermination(60, TimeUnit.SECONDS)) {
//                methodExecutor.shutdownNow();
//            }
//        } catch (InterruptedException e) {
//            fileExecutor.shutdownNow();
//            methodExecutor.shutdownNow();
//            Thread.currentThread().interrupt();
//        }
//    }
}