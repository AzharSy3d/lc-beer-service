package com.vitechin.javadoc.utils;

public class ConsoleProgressListener implements ProgressTracker.ProgressListener {
    private static final int PROGRESS_BAR_WIDTH = 50;
    
    @Override
    public void update(int filesDone, int totalFiles, 
                      int methodsDone, int totalMethods) {
        String progressBar = createProgressBar(filesDone, totalFiles);
        String stats = String.format(
            "Files: %d/%d | Methods: %d/%d",
            filesDone, totalFiles, methodsDone, totalMethods
        );
        
        System.out.print("\r" + progressBar + " " + stats);
    }
    
    private String createProgressBar(int current, int max) {
        int progress = (int) ((double) current / max * PROGRESS_BAR_WIDTH);
        return String.format("[%-" + PROGRESS_BAR_WIDTH + "s]", 
            "=".repeat(Math.min(progress, PROGRESS_BAR_WIDTH)));
    }
}