package com.vitechin.javadoc.model;

import com.github.javaparser.ast.Node;

import java.util.List;

public class MethodMetaData {
    private String signature;
    private List<String> params;
    private String returnType;
    private List<String> exceptions;
    private List<String> annotations;
    private int indentationLevel;
    private transient Node node; // For JavaParser reference
    private String className;

    // Getters and Setters
    public String getSignature() { return signature; }
    public void setSignature(String signature) { this.signature = signature; }

    public List<String> getParams() { return params; }
    public void setParams(List<String> params) { this.params = params; }

    public String getReturnType() { return returnType; }
    public void setReturnType(String returnType) { this.returnType = returnType; }

    public List<String> getExceptions() { return exceptions; }
    public void setExceptions(List<String> exceptions) { 
        this.exceptions = exceptions; 
    }

    public List<String> getAnnotations() { return annotations; }
    public void setAnnotations(List<String> annotations) { 
        this.annotations = annotations; 
    }

    public int getIndentationLevel() { return indentationLevel; }
    public void setIndentationLevel(int indentationLevel) { 
        this.indentationLevel = indentationLevel; 
    }

    public Node getNode() { return node; }
    public void setNode(Node node) { this.node = node; }

    @Override
    public String toString() {
        return "MethodMetaData{" +
            "signature='" + signature + '\'' +
            ", params=" + params +
            ", returnType='" + returnType + '\'' +
            ", exceptions=" + exceptions +
            ", annotations=" + annotations +
            ", indentationLevel=" + indentationLevel +
            '}';
    }

    public void setClassName(String unknown) {
    }

    public String getClassName() {
        return className;
    }
}