package com.vitechin.javadoc.utils;

import com.vitechin.javadoc.config.FilterConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class ProgressTracker {
    private static final Logger logger = LoggerFactory.getLogger(ProgressTracker.class);

    private final AtomicInteger filesToProcess = new AtomicInteger();
    private final AtomicInteger processedFiles = new AtomicInteger();
    private final AtomicInteger totalMethods = new AtomicInteger();

    private final FilterConfig filterConfig;

    public ProgressTracker(FilterConfig filterConfig) {
        this.filterConfig = filterConfig;
    }

    public void startProcessing(long totalFilesInModules,long filesToProcess) throws IOException {

        this.filesToProcess.set((int) filesToProcess);
        logger.info("Total Java files in selected modules: {}", totalFilesInModules);
        logger.info("Java files selected based on filter config {}: count: {}", filterConfig.getTargetClassPatterns(), filesToProcess);
        logger.info("Starting documentation generation for {} files...", filesToProcess);
    }

    public void updateFileProgress(Path filePath, int methodsProcessed) {
        int filesDone = processedFiles.incrementAndGet();

        logger.info("\rProgress: {}/{} files | {} methods processed | Current file: {}",
                filesDone, filesToProcess.get(), totalMethods.get(), filePath.getFileName());
    }

    public void complete() {
        logger.info("\nDocumentation generation complete! Processed {} files and {} methods.\n",
                processedFiles.get(), totalMethods.get());
    }

    public void updateMethodProcessedCount() {  // Called for each method processed
        totalMethods.incrementAndGet();
    }

    public interface ProgressListener {
        void update(int processedFiles, int totalFiles,
                    int processedMethods, int totalMethods);
    }
}