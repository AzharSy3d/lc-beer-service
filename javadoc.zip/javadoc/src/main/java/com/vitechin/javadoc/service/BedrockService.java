package com.vitechin.javadoc.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.vitechin.javadoc.model.MethodMetaData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.bedrockruntime.BedrockRuntimeClient;
import software.amazon.awssdk.services.bedrockruntime.model.InvokeModelRequest;
import software.amazon.awssdk.services.bedrockruntime.model.InvokeModelResponse;
import software.amazon.awssdk.thirdparty.jackson.core.JsonProcessingException;

import java.util.concurrent.Semaphore;
import java.util.function.Supplier;

@Service
public class BedrockService {
    private static final Logger logger = LoggerFactory.getLogger(BedrockService.class);
    private static final String MODEL_ID = "anthropic.claude-instant-v1"; // Recommended model
    private static final int MAX_CONCURRENT_REQUESTS = 500; // Optimal for AWS rate limits

    private final BedrockRuntimeClient bedrockClient;
    private final Semaphore rateLimiter = new Semaphore(MAX_CONCURRENT_REQUESTS);
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public BedrockService() {
        this.bedrockClient = BedrockRuntimeClient.builder()
                .region(Region.US_EAST_1)
                .credentialsProvider(ProfileCredentialsProvider.create())
                .build();
    }

    public String generateMethodDoc(MethodMetaData method) {
        return withRetry(() -> {
            try {
                rateLimiter.acquire();
                return generateDocInternal(method);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("Thread interrupted", e);
            } finally {
                rateLimiter.release();
            }
        });
    }

    private String generateDocInternal(MethodMetaData method) {
        try {
            String prompt = createPrompt(method);
            JsonNode requestBody = createRequestBody(prompt);

            InvokeModelRequest request = InvokeModelRequest.builder()
                    .modelId(MODEL_ID)
                    .contentType("application/json")
                    .body(SdkBytes.fromUtf8String(objectMapper.writeValueAsString(requestBody)))
                    .build();

            InvokeModelResponse response = bedrockClient.invokeModel(request);
            return parseResponse(response);
        } catch (Exception e) {
            throw new RuntimeException("API call failed", e);
        }
    }

    private JsonNode createRequestBody(String prompt) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("anthropic_version", "bedrock-2023-05-31");
        body.put("prompt", prompt);
        body.put("max_tokens_to_sample", 2048);
        body.put("temperature", 0.5);
        body.put("top_k", 250);
        body.put("top_p", 1.0);
        return body;
    }

    private String parseResponse(InvokeModelResponse response) throws JsonProcessingException, com.fasterxml.jackson.core.JsonProcessingException {
        JsonNode responseJson = objectMapper.readTree(response.body().asUtf8String());
        return responseJson.path("completion").asText().trim();
    }

    private String withRetry(Supplier<String> action) {
        int retries = 0;
        while (retries < 3) {
            try {
                return action.get();
            } catch (Exception e) {
                if (++retries == 3) throw e;
                logger.warn("Retry attempt {} for API call", retries);
                sleepExponentially(retries);
            }
        }
        throw new RuntimeException("Max retries exceeded");
    }

    private void sleepExponentially(int retryCount) {
        try {
            long delay = (long) Math.pow(2, retryCount) * 1000;
            Thread.sleep(delay);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }


    private String createPrompt(MethodMetaData method) {
        return String.format("""
        \n\nHuman: Generate JavaDoc for this method following Oracle standards:
        - Start with /**
        - Provide a brief description
        - Use @param, @return, @throws
        - Place above annotations
        - No technical explanations
        - Match existing code style
        - Do not include words like "Here is the java doc for the method etc"
        
        Method:
        %s
        \n\nAssistant:""",
                method.getSignature());
    }
}
