package com.vitechin.javadoc;

import com.vitechin.javadoc.service.DocGeneratorService;
import com.vitechin.javadoc.service.GitHubCLIService;
import com.vitechin.javadoc.service.UserInteractionService;
import com.vitechin.javadoc.utils.LogExporter;
import com.vitechin.javadoc.utils.ProgressTracker;
import com.vitechin.javadoc.utils.RepoAnalyzer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

@SpringBootApplication
public class JavaDocGeneratorApplication implements CommandLineRunner {
    private static final Logger logger = LoggerFactory.getLogger(JavaDocGeneratorApplication.class);

    @Autowired private RepoAnalyzer repoAnalyzer;
    @Autowired private UserInteractionService uiService;
    @Autowired private DocGeneratorService docService;
    @Autowired private ProgressTracker progressTracker;
    @Autowired private GitHubCLIService gitHubService;
    @Autowired private LogExporter logExporter;

    private final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        SpringApplication.run(JavaDocGeneratorApplication.class, args);
    }

    @Override
    public void run(String... args) {
        try {
            // Get repository path
            Path repoPath = getRepoPath();

            // Verify Git status
            verifyGitStatus(repoPath);

            // Process documentation
            long startTime = System.currentTimeMillis();
            processRepository(repoPath);
//        TODO    logProcessingTime(startTime);

            // Post-processing
            logExporter.exportLogs();
            handlePrCreation(repoPath);

        } catch (Exception e) {
            logger.error("Application failed: {}", e.getMessage());
            logExporter.exportLogs();
            System.exit(1);
        }
    }

    private Path getRepoPath() throws IOException {
        System.out.print("Enter repository path/URL: ");
        String input = scanner.nextLine().trim();
        return repoAnalyzer.resolvePath(input);
    }

    private void verifyGitStatus(Path repoPath) {
        if (!gitHubService.isGitRepo(repoPath)) {
            throw new RuntimeException("Not a Git repository");
        }

        if (gitHubService.hasLocalChanges(repoPath)) {
            throw new RuntimeException("Local changes exist or repo not updated. Please stash changes or sync with upstream.");
        }
    }

    private void processRepository(Path repoPath) throws IOException {
        List<String> modules = uiService.selectModules(repoPath);
//        progressTracker.startProcessing(repoPath);
        docService.processDirectory(repoPath, modules);
        progressTracker.complete();
    }

    private void logProcessingTime(long startTime) {
        long duration = System.currentTimeMillis() - startTime;
        String timeTaken = String.format("%d min %d sec",
                TimeUnit.MILLISECONDS.toMinutes(duration),
                TimeUnit.MILLISECONDS.toSeconds(duration) % 60);
        logger.info("Processing completed in {}", timeTaken);
    }

    private void handlePrCreation(Path repoPath) {
        System.out.print("\nCreate Pull Request? (y/n): ");
        if (scanner.nextLine().equalsIgnoreCase("y")) {
            String branchName = prompt("Enter new branch name: ");
            String commitMessage = prompt("Enter commit message: ");

            try {
                gitHubService.createPullRequest(repoPath, branchName, commitMessage);
                logger.info("✅ Changes pushed successfully!");
                // Print the remote URL for the branch
                String remoteUrl = gitHubService.getRemoteUrl(repoPath);
                logger.info("Remote URL: {}", remoteUrl);
                logger.info("Review Changes on above URL and create PR manually");

            } catch (Exception e) {
                logger.error("PR creation failed: {}", e.getMessage());
            }
        }
    }

    private String prompt(String message) {
        System.out.print(message);
        return scanner.nextLine().trim();
    }
}