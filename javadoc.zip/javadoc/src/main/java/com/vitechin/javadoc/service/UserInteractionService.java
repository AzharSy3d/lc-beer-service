package com.vitechin.javadoc.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class UserInteractionService {
    private static final Logger logger = LoggerFactory.getLogger(UserInteractionService.class);
    private final Scanner scanner = new Scanner(System.in);

    public List<String> selectModules(Path repoPath) throws IOException {
        List<String> modules = detectModules(repoPath);
        logger.info("\nDetected modules:");
        AtomicInteger index = new AtomicInteger(1);
        modules.forEach(m -> System.out.println(index.getAndIncrement() + ". " + m));

        logger.info("\nEnter module/directory numbers (comma-separated) or 'all': ");
        String input = scanner.nextLine();

        if (input.equalsIgnoreCase("all")) {
            return modules;
        }
        return Arrays.stream(input.split(","))
            .map(Integer::parseInt)
            .map(i -> modules.get(i-1))
            .collect(Collectors.toList());
    }

    public Optional<String> parseModuleName(Path repoPath) throws IOException {
        // List directories in the repo
        if (Files.isDirectory(repoPath)) {
            return Optional.of(repoPath.getFileName().toString());
        }
        return Optional.empty();
    }

    private String prompt(String message) {
        System.out.print(message);
        return scanner.nextLine();
    }
    private List<String> detectModules(Path repoPath) throws IOException {
        // List all directories (modules) in the given repoPath
        try (Stream<Path> paths = Files.walk(repoPath, 1)) {
            return paths
                    .filter(Files::isDirectory)  // Only directories (no files)
                    .map(path -> path.getFileName().toString())  // Extract folder names
                    .filter(name -> !name.equals(repoPath.getFileName().toString())) // Exclude the root folder
                    .collect(Collectors.toList());
        }
    }

}

