package com.vitechin.javadoc.service;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.vitechin.javadoc.model.MethodMetaData;
import com.vitechin.javadoc.config.FilterConfig;
import com.vitechin.javadoc.utils.ProgressTracker;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Service
public class DocGeneratorService {
    private static final Logger logger = LoggerFactory.getLogger(DocGeneratorService.class);

    private final BedrockService bedrockService;

    private final FilterConfig filterConfig;

    private final ProgressTracker progressTracker;

    @Value("${app.max-concurrent-files:100}")
    private int maxConcurrentFiles;

    @Value("${app.max-concurrent-methods:1000}")
    private int maxConcurrentMethods;

//    private final ExecutorService fileExecutor = Executors.newVirtualThreadPerTaskExecutor();
//    private final ExecutorService methodExecutor = Executors.newVirtualThreadPerTaskExecutor();

    private final ExecutorService fileExecutor;
    private final ExecutorService methodExecutor;


    public DocGeneratorService(BedrockService bedrockService, FilterConfig filterConfig, ProgressTracker progressTracker) {
        this.bedrockService = bedrockService;
        this.filterConfig = filterConfig;
        this.progressTracker = progressTracker;
        this.fileExecutor = Executors.newFixedThreadPool(100);
        this.methodExecutor = Executors.newFixedThreadPool(1000);
    }


    public void processDirectory(Path rootDir, List<String> modules) {
        long startTime = System.currentTimeMillis();
        try {
            List<Path> allFilesInModules = Files.walk(rootDir)
                    .filter(p -> p.toString().endsWith(".java"))
                    .filter(p -> isInSelectedModule(p, modules))
                    .toList();

            long totalFilesInModules = allFilesInModules.size();

            long filesToProcessCount = allFilesInModules.stream()
                    .filter(this::shouldProcessFile).count();

            progressTracker.startProcessing(totalFilesInModules, filesToProcessCount);

            List<CompletableFuture<Void>> fileFutures = Files.walk(rootDir)
                    .filter(p -> p.toString().endsWith(".java"))
                    .filter(p -> isInSelectedModule(p, modules))
                    .filter(this::shouldProcessFile)
                    .map(this::processFileAsync)
                    .collect(Collectors.toList());


            CompletableFuture.allOf(fileFutures.toArray(new CompletableFuture[0])).join();
            long endTime = System.currentTimeMillis();
            long timeTaken = endTime - startTime;
            String duration = String.format("%d min %d sec",
                    TimeUnit.MILLISECONDS.toMinutes(timeTaken),
                    TimeUnit.MILLISECONDS.toSeconds(timeTaken) % 60);

//            System.out.printf("\nDocumentation generation completed in %s\n", duration);
        } catch (IOException e) {
            logger.error("Failed to process directory: {}", rootDir, e);
            throw new RuntimeException("Directory processing failed", e);
        }
    }

    private CompletableFuture<Void> processFileAsync(Path filePath) {
        return CompletableFuture.runAsync(() -> {
            try {
                // Read the original file content
                List<String> originalLines = Files.readAllLines(filePath, StandardCharsets.UTF_8);

                // Process the file content to add Javadoc
                List<String> updatedLines = processFileContent(filePath, originalLines);

                // Write the updated content only if changes were made
                if (!updatedLines.equals(originalLines)) {
                    Files.write(filePath, updatedLines, StandardCharsets.UTF_8);
                    progressTracker.updateFileProgress(filePath, 1);
                    logger.info("Updated file: {}", filePath);
                } else {
                    logger.debug("No changes needed for file: {}", filePath);
                }
            } catch (Exception e) {
                logger.error("Failed to process file: {}", filePath, e);
                throw new CompletionException(e);
            }
        }, fileExecutor);
    }

    private List<String> processFileContent(Path filePath, List<String> originalLines) throws IOException {
        CompilationUnit cu = StaticJavaParser.parse(filePath);
        List<MethodDeclaration> methods = cu.findAll(MethodDeclaration.class);

        // Track changes to avoid rewriting the entire file
        Map<Integer, String> changes = new TreeMap<>();

        for (MethodDeclaration md : methods) {
            if (!md.hasJavaDocComment() &&
                    filterConfig.shouldProcess(md.findAncestor(ClassOrInterfaceDeclaration.class).orElseThrow())) {

                // Skip nested methods
                if (isNestedMethod(md)) continue;
                // Generate and clean the Javadoc
                String javaDoc = bedrockService.generateMethodDoc(extractMetadata(md));
                String cleanJavaDoc = cleanGeneratedJavaDoc(javaDoc);

                // Get the method's start line (0-based index)
                int methodStartLine = md.getRange()
                        .map(r -> r.begin.line - 1) // Convert to 0-based index
                        .orElseThrow(() -> new RuntimeException("Method has no range information"));
                progressTracker.updateMethodProcessedCount();

                // Calculate indentation from the method declaration
                String methodLine = originalLines.get(methodStartLine);
                String indentation = methodLine.replaceAll("^\\s*", "").isEmpty()
                        ? ""
                        : methodLine.substring(0, methodLine.indexOf(methodLine.trim()));

                // Apply indentation to the Javadoc
                String indentedJavaDoc = applyIndentation(cleanJavaDoc, indentation);

                // Insert the Javadoc at the correct position
                changes.put(methodStartLine, indentedJavaDoc);
            }
        }

        // Apply changes to the file content
        if (!changes.isEmpty()) {
            return applyChangesToFile(originalLines, changes);
        }

        // Return original content if no changes
        return originalLines;
    }

    private boolean isNestedMethod(MethodDeclaration md) {
        String methodName = md.getNameAsString();
        return methodName.equals("callback") ||
                methodName.equals("doInHibernate") ||
                methodName.startsWith("lambda$") ||
                methodName.equals("execute") ||
                methodName.equals("evaluate");
    }


    private List<String> applyChangesToFile(List<String> lines, Map<Integer, String> changes) {
        List<String> updatedLines = new ArrayList<>();
        int currentLine = 0;

        for (Map.Entry<Integer, String> entry : changes.entrySet()) {
            int changeLine = entry.getKey();
            String javadoc = entry.getValue();

            // Copy lines before the change
            while (currentLine < changeLine) {
                updatedLines.add(lines.get(currentLine));
                currentLine++;
            }

            // Insert the Javadoc
            updatedLines.add(javadoc);

            // Copy the method declaration line (preserve annotations and signature)
            updatedLines.add(lines.get(currentLine));
            currentLine++;
        }

        // Copy remaining lines
        while (currentLine < lines.size()) {
            updatedLines.add(lines.get(currentLine));
            currentLine++;
        }

        return updatedLines;
    }

    private String applyIndentation(String content, String indentation) {
        return content.lines()
                .map(line -> indentation + line)
                .collect(Collectors.joining("\n"));
    }


    private String cleanGeneratedJavaDoc(String javaDoc) {
        // Remove code blocks and method signatures
        javaDoc = javaDoc.replaceAll("```java", "")
                .replaceAll("```", "")
                .replaceAll("(?i)method signature:.*", "")
                .replace("* /", "*/")
                .trim();

        // Ensure proper Javadoc format
        if (!javaDoc.startsWith("/**")) {
            javaDoc = "/**\n" + javaDoc;
        }
        if (!javaDoc.endsWith("*/")) {
            javaDoc = javaDoc + "\n*/";
        }

        // Remove extra phrases
        javaDoc = javaDoc.replaceAll("(?i)generated javadoc:", "")
                .replaceAll("(?i)javadoc for method:", "")
                .trim();

        // Remove everything after */
        int endIndex = javaDoc.indexOf("*/") + 2;
        if (endIndex < javaDoc.length()) {
            javaDoc = javaDoc.substring(0, endIndex);
        }

        // Format the Javadoc correctly
        String[] lines = javaDoc.split("\n");
        StringBuilder formattedJavaDoc = new StringBuilder();
        for (String line : lines) {
            if (line.trim().startsWith("*")) {
                formattedJavaDoc.append(" ").append(line.trim()).append("\n");
            } else {
                formattedJavaDoc.append(line.trim()).append("\n");
            }
        }

        return formattedJavaDoc.toString().trim();
    }


    /**
     * Check if a file belongs to the selected modules.
     */
    private boolean isInSelectedModule(Path filePath, List<String> modules) {
        return modules.stream()
                .anyMatch(module -> filePath.toString().contains(module));
    }

    /**
     * Check if a file should be processed based on filters.
     */
    private boolean shouldProcessFile(Path filePath) {
        try {
            CompilationUnit cu = StaticJavaParser.parse(filePath);
            return cu.findAll(ClassOrInterfaceDeclaration.class).stream()
                    .anyMatch(filterConfig::shouldProcess);
        } catch (IOException e) {
            logger.warn("Failed to parse file for filtering: {}", filePath, e);
            return false;
        }
    }


    /**
     * Extract metadata from a method.
     */
    private MethodMetaData extractMetadata(MethodDeclaration md) {
        MethodMetaData meta = new MethodMetaData();
        meta.setSignature(md.getDeclarationAsString());
        meta.setParams(md.getParameters().stream()
                .map(p -> p.toString())
                .collect(Collectors.toList()));
        meta.setReturnType(md.getType().asString());
        meta.setIndentationLevel(getIndentationLevel(md));
        meta.setClassName(md.findAncestor(ClassOrInterfaceDeclaration.class)
                .map(ClassOrInterfaceDeclaration::getNameAsString)
                .orElse("Unknown"));
        return meta;
    }

    /**
     * Get the indentation level of a method.
     */
    private int getIndentationLevel(MethodDeclaration md) {
        return md.getRange()
                .flatMap(r -> Optional.ofNullable(r.begin).map(b -> b.column))
                .orElse(0);
    }


    @PreDestroy
    public void cleanup() {
        fileExecutor.shutdown();
        methodExecutor.shutdown();
        try {
            if (!fileExecutor.awaitTermination(60, TimeUnit.SECONDS)) {
                fileExecutor.shutdownNow();
            }
            if (!methodExecutor.awaitTermination(60, TimeUnit.SECONDS)) {
                methodExecutor.shutdownNow();
            }
        } catch (InterruptedException e) {
            fileExecutor.shutdownNow();
            methodExecutor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}