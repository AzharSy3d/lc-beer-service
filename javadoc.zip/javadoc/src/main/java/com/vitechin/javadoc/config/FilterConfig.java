package com.vitechin.javadoc.config;

import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "filters")
public class FilterConfig {
    private Map<String, List<String>> targetClassPatterns = new HashMap<>();
    private List<String> excludePatterns = new ArrayList<>();

    // Getters and setters
    public Map<String, List<String>> getTargetClassPatterns() {
        return targetClassPatterns;
    }

    public void setTargetClassPatterns(Map<String, List<String>> targetClassPatterns) {
        this.targetClassPatterns = targetClassPatterns;
    }

    public List<String> getExcludePatterns() {
        return excludePatterns;
    }

    public void setExcludePatterns(List<String> excludePatterns) {
        this.excludePatterns = excludePatterns;
    }

    public boolean shouldProcess(ClassOrInterfaceDeclaration clazz) {
        String className = clazz.getNameAsString();
        String type = clazz.isInterface() ? "interface" : "class";

        // Check exclude patterns
        if (excludePatterns.stream().anyMatch(className::contains)) {
            return false;
        }

        // Check include patterns
        return targetClassPatterns.getOrDefault(type, List.of()).stream()
                .anyMatch(className::endsWith);
    }
}