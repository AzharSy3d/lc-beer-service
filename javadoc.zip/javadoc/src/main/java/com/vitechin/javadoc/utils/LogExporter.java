package com.vitechin.javadoc.utils;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class LogExporter {
    public void exportLogs() {
        try {
            Path logDir = Paths.get(System.getProperty("user.home"), "Desktop", "JavaDocLogs");
            Files.createDirectories(logDir);
            
            Path logFile = logDir.resolve("javadoc_generation.log");
            try (PrintWriter writer = new PrintWriter(Files.newBufferedWriter(logFile))) {
                writer.println("Documentation Generation Log");
                writer.println("===========================");
                // Add log content here
            }
            
            System.out.println("Logs exported to: " + logFile);
        } catch (IOException e) {
            System.err.println("Failed to export logs: " + e.getMessage());
        }
    }
}
