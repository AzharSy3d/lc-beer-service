package com.vitechin.javadoc.service;

import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.util.Scanner;

@Service
public class GitHubCLIService {
    public boolean isGitRepo(Path path) {
        try {
            Process process = new ProcessBuilder("git", "rev-parse", "--git-dir")
                .directory(path.toFile())
                .start();
            return process.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean hasLocalChanges(Path path) {
        try {
            Process process = new ProcessBuilder("git", "status", "--porcelain")
                .directory(path.toFile())
                .start();
            String output = new String(process.getInputStream().readAllBytes());
            return !output.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    public void createPullRequest(Path path, String branchName, String commitMessage) {
        try {
            new ProcessBuilder("git", "checkout", "-b", branchName)
                .directory(path.toFile())
                .start()
                .waitFor();

            new ProcessBuilder("git", "add", ".")
                .directory(path.toFile())
                .start()
                .waitFor();

            new ProcessBuilder("git", "commit", "-m", commitMessage)
                .directory(path.toFile())
                .start()
                .waitFor();

            new ProcessBuilder("git", "push", "origin", branchName)
                    .directory(path.toFile())
                    .start()
                    .waitFor();

//            new ProcessBuilder("gh", "pr", "create", "--title", commitMessage, "--body", commitMessage)
//                .directory(path.toFile())
//                .start()
//                .waitFor();
        } catch (Exception e) {
            throw new RuntimeException("Failed to create PR", e);
        }
    }

    public String getRemoteUrl(Path path) {
        try {
            Process process = new ProcessBuilder("git", "config", "--get", "remote.origin.url")
                    .directory(path.toFile())
                    .start();
            process.waitFor();
            try (Scanner scanner = new Scanner(process.getInputStream())) {
                return scanner.hasNext() ? scanner.nextLine() : null;
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to get remote URL", e);
        }
    }
}
