package com.vitechin.javadoc.controller;

import com.vitechin.javadoc.service.DocGeneratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class DocGenController {

    @Autowired
    private DocGeneratorService docGeneratorService;

    @PostMapping("/generate")
    public ResponseEntity<String> generateDocs(@RequestParam String directory) {
        Path path = Paths.get(directory);
        if (!Files.exists(path)) {
            return ResponseEntity.badRequest().body("Invalid directory path");
        }
        
//        docGeneratorService.processDirectory(path);
        return ResponseEntity.ok("Documentation generation started");
    }

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getStatus() {
        // Implementation for status trackingreturn nu

        return null;
    }
}
