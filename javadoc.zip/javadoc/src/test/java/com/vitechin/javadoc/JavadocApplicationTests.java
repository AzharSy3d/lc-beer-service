package com.vitechin.javadoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavadocApplicationTests {

	@Test
	void contextLoads() {
	}

}
